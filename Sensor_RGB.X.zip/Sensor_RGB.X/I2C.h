/* 
 * File: I2C.h
 * Author: Francisco Javier L�pez Turcios
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef I2C_H
#define	I2C_H

#include <xc.h> // include processor files - each processor file is guarded. 
#include <stdint.h>
#define _XTAL_FREQ 4000000

void i2c_config_master(const unsigned long SCL);
void i2c_config_slave(uint8_t address);
void i2c_iddle_mode(void);
void i2c_start(void);
void i2c_restart(void);
void i2c_stop(void);
void i2c_write(unsigned byteEnvio);
unsigned short i2c_read(unsigned short Ack_Secuencia);


#endif	

