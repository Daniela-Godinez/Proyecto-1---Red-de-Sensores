/*
 * File:   RGB.c
 * Author: Rodas y Godinez
 *
 * Created on 12 de marzo de 2022, 11:30 PM
 */


// PIC16F887 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>
#include <stdint.h>
#include <string.h>
#include "LCD.h"
#include "I2C.h"
#include "Oscilador.h"
#define _XTAL_FREQ 4000000

//============================================================================
//============================ VARIABLES GLOBALES ============================
//============================================================================
uint8_t seg = 0;
uint8_t aprox = 0;
uint8_t color;
uint8_t sino;
// DIVISION DE UNIDADES DE TIEMPO:
// UNIDADES - DECENAS DE SEGUNDOS:
char unidades_01 = 0;
char decenas_01 = 0;
struct sensorColor
{
    uint8_t high;
    uint8_t low;
    uint16_t highlow;
    uint8_t unidades;
    uint8_t decenas;
    uint8_t centenas;
    uint32_t mapeado;
    uint8_t UNI;
    uint8_t DEC;
    uint8_t CEN;
}red, blue, green, redh, blueh, greenh;

//============================================================================
//========================= DECLARACI�N DE FUNCIONES =========================
//============================================================================
void config_io(void);
void divisor(uint16_t num, uint8_t *centena, uint8_t *decena, uint8_t *unidad);
int traduccion_01 (int a);                 

//============================================================================
//=================================== MAIN ===================================
//============================================================================
void main(void){
    config_io();            // Configurar entradas y salidas
    
    ini_LCD();              // Inicializar LCD
    
    i2c_config_master(400000);    // Configurar pic en I2C como master
    
    // Configuraci�n de ENABLE para despertar del modo sleep
    i2c_start();
    i2c_write(0b01010010);      // 0x29 + Write (0)
    i2c_write(0b10000000);      // Command -> 1, 00, 00000 (ENABLE)
    i2c_write(0b00000001);      // 000, 0 (AIEN), 0 (WEN), 0, 0 (AEN), 1 (PON)
    i2c_stop();
    __delay_ms(5);

    // Configuraci�n de ATIME
    i2c_start();
    i2c_write(0b01010010);      // 0x29 + Write (0)
    i2c_write(0b10000001);      // Command -> 1, 00, 00001 (ATIME)
    i2c_write(0b00000000);      // 256 Ciclos de integraci�n (700ms)
    i2c_stop();
    __delay_ms(5);    
        
    // Configuraci�n de ENABLE para empezar conversiones de ADC
    i2c_start();
    i2c_write(0b01010010);      // 0x29 + Write (0)
    i2c_write(0b10000000);      // Command -> 1, 00, 00000 (ENABLE)
    i2c_write(0b00000011);      // 000, 0 (AIEN), 0 (WEN), 0, 1 (AEN), 1 (PON)
    i2c_stop();
    __delay_ms(5);
    
    while(1)
    {
        __delay_ms(750);
        i2c_start();
        i2c_write(0b01010010);  // 0x29 + Write (0)
        i2c_write(0b10010110);  // Command -> 1, 00 Leer un byte, 10110 (RED LOW)
        i2c_restart();
        i2c_write(0b01010011);  // 0x29 + Read (1)
        red.low     =   i2c_read(1);
        i2c_stop();
        __delay_ms(5);
        
        i2c_start();
        i2c_write(0b01010010);  // 0x29 + Write (0)
        i2c_write(0b10011000);  // Command -> 1, 00 Leer un byte, 10110 (GREEN LOW)
        i2c_restart();
        i2c_write(0b01010011);  // 0x29 + Read (1)
        green.low   =   i2c_read(1);
        i2c_stop();
        __delay_ms(5);

        i2c_start();
        i2c_write(0b01010010);  // 0x29 + Write (0)
        i2c_write(0b10011010);  // Command -> 1, 00 Leer un byte, 10110 (BLUE LOW)
        i2c_restart();
        i2c_write(0b01010011);  // 0x29 + Read (1)
        blue.low    =   i2c_read(1);
        i2c_stop();
        __delay_ms(5);

        divisor(red.low, &red.centenas, &red.decenas, &red.unidades);
        divisor(green.low, &green.centenas, &green.decenas, &green.unidades);
        divisor(blue.low, &blue.centenas, &blue.decenas, &blue.unidades);
        
        set_Cursor(0,0);
        w_String("Color");
        set_Cursor(0,6);
        w_String("DC");
        set_Cursor(0,10);
        w_String("T");
        set_Cursor(0,13);
        w_String("Vel");
        
        if(red.low > 100 && green.low < 100 && blue.low < 100){
            set_Cursor(1,0);
            w_String("ROJO ");
            color = 1;
        }else if(red.low < 100 && green.low > 100 && blue.low < 100){
            set_Cursor(1,0);
            w_String("VERDE");
            color = 2;
        }else if(red.low < 100 && green.low < 100 && blue.low > 100){
            set_Cursor(1,0);
            w_String("AZUL ");
            color = 3;
        }else{
            set_Cursor(1,0);
            w_String(" N/A ");
            color = 4;
        }
        
        // SOLICITUD DE DATOS AL SENSOR:
        // INICIAMOS LA COMUNICACION I2C (LIBRER�A):
        i2c_start();         
        // ESTABLECEMOS SI SE ENVIARAN O RECIBIRAN DATOS Y EL ADDRESS:
        i2c_write(0xD0);  
        // ESCRIBIMOS = 0:
        i2c_write(0); 
        // DETENEMOS EL PROCESO:
        i2c_stop(); 
        // DAMOS UN DELAY PARA PROCESAR:
        __delay_ms(10);
        
    // *****************************************************************
        // PROCESO DE LECTURA DEL SENSOR:
        // INICIAMOS LA COMUNICACION I2C (LIBRER�A):
        i2c_start();         
        // ESTABLECEMOS SI SE ENVIARAN O RECIBIRAN DATOS Y EL ADDRESS + 1:
        i2c_write(0xD1);   
        // LEEMOS Y ENVIAMOS EL "OK" = ACKNOWLEDGE = ACK.
        // ESTO PARA CADA UNIDAD DE TIEMPO.
        // APROVECHAR PARA REALIZAR LA CONVERSI�N:
        seg = traduccion_01(i2c_read(1)); 
        // DETENEMOS EL PROCESO:
        i2c_stop();  
        // DAMOS UN DELAY PARA PROCESAR:
        __delay_ms(10);
        
        // OBTENCION DE UNIDADES, DECENAS, CENTENAS DE UNIDAD DE TIEMPO:
        // SEGUNDOS:
        unidades_01 = seg%10; 
        decenas_01 = seg/10; 
        
        set_Cursor(1,9);
        w_Char(decenas_01+'0');
        w_Char(unidades_01+'0');
        
        if(PORTEbits.RE0 == 0){
            set_Cursor(1,6);    
            w_String("NO");
            sino = 15;
        }else if(PORTEbits.RE0 == 1){
            set_Cursor(1,6);
            w_String("SI");
            sino = 14;
        }
        __delay_ms(5);
        
        if(PIR1bits.TXIF){                                              //Verifica la bandera de TXIF - Transmision
            TXREG = color;
            __delay_ms(5);
            TXREG = seg;
            __delay_ms(5);
        }
    }
}

//============================================================================
//================================ FUNCIONES =================================
//============================================================================
void config_io(void)
{
    ANSEL = 0;                  // Pines digitales
    ANSELH = 0;
    
    TRISA = 0;                  // PORTD    (LCD)
    TRISC = 0b00;               // RS y E   (LCD)
    
    TRISEbits.TRISE0 = 1;
    
    PORTE = 0;
    
    PORTA = 0;                  // Condiciones iniciales
    PORTC = 0;                  // 
    
    initOsc(0); 
    red.low = 0;
    red.centenas = 0;
    red.decenas = 0;
    red.unidades = 0;
    
    //CONFIGURACI�N DEL COMUNICACI�N SERIAL
    //SYNC = 0, BRGH = 1; BRG16 = 1
    //SPBRG = 25
    TXSTAbits.SYNC = 0;      //Modo as�ncrono
    TXSTAbits.BRGH = 1;      //Alta velocidad en modo as�ncrono
    BAUDCTLbits.BRG16 = 1;   //16-bit Baud Rate Generator es usado
    
    SPBRG = 207;
    SPBRGH = 0;              //Bits m�s significativos en 0, ya que solo necestiamos los menos significativos
    
    RCSTAbits.SPEN = 1;      //Habilitamos comunicaci�n
    RCSTAbits.RX9 = 0;       //Usamos solo 8 bits
    TXSTAbits.TX9 = 0;
    RCSTAbits.CREN = 0;      //Habilitamos recepci�n
    TXSTAbits.TXEN = 1;      //Habilitamos la transmision
    
    //CONFIGURACI�N INTERUPCCIONES
    INTCONbits.GIE = 1;     //Se habilita las banderas globales
    INTCONbits.PEIE = 1;    //Se habilita las banderas perifericas
    PIE1bits.RCIE = 0;       //Interupcci�n de recepci�n
    PIE1bits.TXIE = 1;       //Interupcci�n de transmisi�n
    return;
}

void divisor(uint16_t num, uint8_t *centena, uint8_t *decena, uint8_t *unidad)  // Divisor que saca los d�gitos de un n�mero
{
    *centena = num / 100;       // Obtener centenas
    uint8_t aux = num % 100;    // Auxliar que almacena decenas y unidades
    *decena = aux / 10;         // Obtener decenas
    *unidad = aux % 10;         // Obtener unidades
    return;
}

int traduccion_01 (int a)
{ 
    return (a >> 4) * 10 + (a & 0x0F);
}