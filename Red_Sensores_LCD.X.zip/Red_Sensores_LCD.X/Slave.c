/* 
 * File:   Master.c
 * Author: Daniela Godinez
 *
 * Created on 13 de septiembre de 2022, 18:57
 */

// PIC16F887 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#define _XTAL_FREQ 4000000

#include <xc.h>
#include "Oscilador.h"
#include "pwm.h"
#include "SPI.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/*
 * VARIABLES
 */
uint8_t color;
uint8_t sino;
uint8_t seg;
uint16_t last_color = 5;
uint16_t pedir = 5;
uint8_t ONOFF = 0;
int i;

/*
 * PROTOTIPO DE FUNCIONES
 */

/*
 * INTERRUPCIONES
 */
void __interrupt() isr (void){                                      //INICIO DE INTERRUPCION
    if(PIR1bits.RCIF){                                              //Verifica la bandera de TXIF - Transmision
        color = RCREG;
        __delay_ms(5);
        seg = RCREG;
        __delay_ms(5);
        PIR1bits.RCIF = 0;                                          //Limpia la bandera de TXIF
    }                                                               //Finaliza la verificacion de la bandera de RCIF
    if(RBIF){
        if(!PORTBbits.RB1){
            if(ONOFF == 0){
                ONOFF = 1;
            }else{
                ONOFF = 0;
            }
        }
        PORTB = PORTB;
        INTCONbits.RBIF = 0;
    }
    
    if(PIR1bits.SSPIF){         //Verificacion de bandera SSPIF  
        pedir = spiRead(); //Se lee el Master
        spiWrite(color);
        PIR1bits.SSPIF = 0;
    } 
    
    
    
    return;                                                         //Vuelve a repetir la interrupcion
} 

/*
 * ENTRADAS Y SALIDAS
 */
void setup(void){
    ANSEL = 0;
    ANSELH = 0;               // I/O digitales
    
    //ENTRADAS
    TRISBbits.TRISB1 = 1;     //RB0 PUSH-BUTTON
    OPTION_REGbits.nRBPU = 0; //Habilitaci�n de PORTB pull-ups
    WPUBbits.WPUB1 = 1;       //Habilitamos Pull-Up en RB2
    
    //SALIDA
    TRISA = 0;
    TRISD = 0;
    
    //LIMPIAR
    PORTA = 0;
    PORTD = 0;
    
    //CONFIGURACION OSCILADOR
    initOsc(0);               //Oscilador de 4Mhz
    
    pwm_init(1);
    
    //SSPM = 0100 (SPI Slave mode, clock = SCK pin, SS pin control enabled), SSPEN = 1 (SCK, SDO, SDI y SS); SPM = 0; CKP = 0 - Reloj inactivo en 0; CKE = 1
    spiInit(SPI_SLAVE_SS_EN, SPI_DATA_SAMPLE_MIDDLE, SPI_CLOCK_IDLE_LOW, SPI_IDLE_2_ACTIVE);
    
    
    //CONFIGURACI�N DEL COMUNICACI�N SERIAL
    //SYNC = 0, BRGH = 1; BRG16 = 1
    //SPBRG = 25
    TXSTAbits.SYNC = 0;      //Modo as�ncrono
    TXSTAbits.BRGH = 1;      //Alta velocidad en modo as�ncrono
    BAUDCTLbits.BRG16 = 1;   //16-bit Baud Rate Generator es usado
    
    SPBRG = 207;
    SPBRGH = 0;              //Bits m�s significativos en 0, ya que solo necestiamos los menos significativos
    
    RCSTAbits.SPEN = 1;      //Habilitamos comunicaci�n
    RCSTAbits.RX9 = 0;       //Usamos solo 8 bits
    TXSTAbits.TX9 = 0;
    RCSTAbits.CREN = 1;      //Habilitamos recepci�n
    TXSTAbits.TXEN = 0;      //Habilitamos la transmision
    
    //CONFIGURACI�N INTERUPCCIONES
    INTCONbits.GIE = 1;     //Se habilita las banderas globales
    INTCONbits.PEIE = 1;    //Se habilita las banderas perifericas
    PIE1bits.RCIE = 1;       //Interupcci�n de recepci�n
    PIE1bits.TXIE = 0;       //Interupcci�n de transmisi�n
    IOCBbits.IOCB1 = 1;     //Interrupcion del RB0
    INTCONbits.RBIE = 1;     //Interrupcion del PORTB
    INTCONbits.RBIF = 0;     //Interrupcion del PORTB
    PIR1bits.SSPIF = 0;     //Limpiar bandera SPI
    PIE1bits.SSPIE = 1;     //Se habilita interrupci�n de SPI
}

/*
 * OTRAS FUNCIONES
 */
void servo(unsigned short mov){
    if (mov == 1){
        pwm_duty_cycle(94); // PWM -> 90�
    }
    else{
        pwm_duty_cycle(31); // PWM -> 0�
    }
    
    if (mov != last_color){ //Se actualiza sensor solo si hay cambio
        last_color = mov;
    }
    return;
}


/*
 * MAIN
 */
int main(void) { //Funci�n que empezar� a ejecutar nuestro PIC al iniciar
    setup();    //Llamamos al setup ya que es necesario al inicializar mi PIC
    
    while(1){
        servo(color);
        
        //INICIALIZACION DEL STEPPER + PUSHBUTTON
        if(ONOFF == 1){
            for(int j=0;j<48;j++){
                PORTD =(1<<i);
                i++;
                __delay_ms(5);
                if(i==4)
                    i=0;
            }   
        }
        if(sino == 15){
            PORTA = 0;
            PORTAbits.RA0 = 1;
            PORTAbits.RA7 = 1;
        }else if(sino == 14){
            PORTA = 0;
            PORTAbits.RA1 = 1;
            PORTAbits.RA7 = 0;
        }
    }
    return(1);
}
